# bpr-spark

Bayesian Personalized Ranking for Spark

[Link to paper with explained architecture](https://stanford.edu/~rezab/classes/cme323/S16/projects_reports/rodrigo_oliveira.pdf)
